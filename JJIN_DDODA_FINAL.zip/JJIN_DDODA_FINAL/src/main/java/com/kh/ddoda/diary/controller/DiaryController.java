package com.kh.ddoda.diary.controller;

public class DiaryController {

}
