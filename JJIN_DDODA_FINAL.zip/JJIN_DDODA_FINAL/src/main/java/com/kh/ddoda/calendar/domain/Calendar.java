package com.kh.ddoda.calendar.domain;

public class Calendar {

}
