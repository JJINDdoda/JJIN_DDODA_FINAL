package com.kh.ddoda.notice.domain;

public class Search {

}
