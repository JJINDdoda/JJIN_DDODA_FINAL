package com.kh.ddoda.diary.service;

public class DiaryServiceImpl {

}
