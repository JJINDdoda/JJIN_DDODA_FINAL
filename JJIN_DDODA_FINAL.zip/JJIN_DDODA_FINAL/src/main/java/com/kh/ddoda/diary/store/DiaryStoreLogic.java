package com.kh.ddoda.diary.store;

public class DiaryStoreLogic {

}
