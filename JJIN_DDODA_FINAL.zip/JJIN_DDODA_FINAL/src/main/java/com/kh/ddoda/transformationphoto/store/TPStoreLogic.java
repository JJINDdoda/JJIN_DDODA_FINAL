package com.kh.ddoda.transformationphoto.store;

public class TPStoreLogic {

}
