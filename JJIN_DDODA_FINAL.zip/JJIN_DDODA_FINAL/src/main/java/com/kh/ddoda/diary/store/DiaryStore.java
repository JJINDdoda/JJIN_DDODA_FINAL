package com.kh.ddoda.diary.store;

public interface DiaryStore {

}
