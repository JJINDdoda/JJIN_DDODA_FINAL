package com.kh.ddoda.diary.service;

public interface DiaryService {

}
