package com.kh.ddoda.transformationphoto.service;

public interface TPService {

}
