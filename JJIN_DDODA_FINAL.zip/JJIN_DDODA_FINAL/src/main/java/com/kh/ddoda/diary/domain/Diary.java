package com.kh.ddoda.diary.domain;

public class Diary {

}
