package com.kh.ddoda.transformationphoto.domain;

public class TPhoto {

}
