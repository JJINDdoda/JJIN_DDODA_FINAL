package com.kh.ddoda.transformationphoto.store;

public interface TPStore {

}
